<!DOCTYPE html>
<html dir="ltr" lang="en">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="keywords" content="">
      <meta name="description" content="">
      <!-- css file -->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <link rel="stylesheet" href="css/menu.css">
      <link rel="stylesheet" href="css/style.css">
      <link rel="stylesheet" href="css/custom.css">
      <!-- Responsive stylesheet -->
      <link rel="stylesheet" href="css/responsive.css">
      <!-- Title -->
      <title>Home | AHEAD - Online Degree Programs</title>
      <!-- Favicon -->
      <link href="images/amrita-ahead-logo.png" sizes="194x194" rel="shortcut icon" type="image/x-icon" />
      <link href="images/amrita-ahead-logo.png" sizes="194x194" rel="shortcut icon" />
      <script src="https://apps.elfsight.com/p/platform.js" defer></script>
   </head>
   <body>
      <div class="wrapper">
      <div class="preloader"></div>
      <div class="header_top home4">
         <div class="container">
            <div class="row">
               <div class="col-lg-5 col-xl-5">
                  <ul class="home4_header_top_contact">
                     <li class="list-inline-item"><a target="blank" href="https://www.amrita.edu/international">INTERNATIONAL</a></li>
                     <li class="list-inline-item"><a target="blank" href="https://www.amrita.edu/amritians">ALUMNI</a></li>
                     <li class="list-inline-item"><a target="blank" href="https://www.amrita.edu/faculty">FACULTY</a></li>
                  </ul>
               </div>
               <div class="col-lg-7 col-xl-7">
                  <ul class="sign_up_btn home4 dn-smd text-right">
                     <li class="list-inline-item"><a target="blank" href="https://www.amrita.edu/admissions" class="btn btn-md"><span class="dn-md">ADMISSION - 2021</span></a></li>
                  </ul>
               </div>
            </div>
         </div>
      </div>
      <!-- Main Header Nav -->
      <header class="header-nav menu_style_home_four navbar-scrolltofixed stricky main-menu">
         <div class="container">
            <!-- Ace Responsive Menu -->
            <nav>
               <!-- Menu Toggle btn-->
               <div class="menu-toggle">
                  <img class="nav_logo_img img-fluid" src="images/amrita-ahead-logo.jpg" alt="header-logo.jpg">
                  <button type="button" id="menu-btn">
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  </button>
               </div>
               <a href="index.php" class="navbar_brand float-left dn-smd">
               <img class="logo1 img-fluid" src="images/aheadlogo.svg" alt="header-logo" style="width: 300px; height: 65px;">
               <img class="logo2 img-fluid" src="images/aheadlogosticky.svg" alt="header-logo2.png" style="height: 50px;">		            
               </a>
               <!-- Responsive Menu Structure-->
               <ul id="respMenu" class="ace-responsive-menu" data-menu-style="horizontal">
                  <li class="last">
                     <a href="contact.php"><span class="title">Contact</span></a>
                  </li>
                  <li class="list_two">
                     <a href="#"><span class="title">Programs</span></a>
                     <!-- Level Two-->
                     <ul>
                        <li><a href="mba.php">MBA</a></li>
                        <li><a href="mca.php">MCA</a></li>
                        <li><a href="bba.php">BBA</a></li>
                     </ul>
                  </li>
                  <li class="list_one">
                     <a href="index.php"><span class="title">Home</span></a>
                     <!-- Level Two-->
                  </li>
               </ul>
            </nav>
            <!-- End of Responsive Menu -->
         </div>
      </header>
      <!-- Main Header Nav For Mobile -->
      <div id="page" class="stylehome1 h0">
         <div class="mobile-menu">
            <div class="header stylehome1">
               <div class="main_logo_home2">
                  <img class="nav_logo_img img-fluid float-left mt20" src="images/aheadlogo.svg" alt="header-logo.png" style="width: 236px;">
               </div>
               <ul class="menu_bar_home2">
                  <li class="list-inline-item">
                  </li>
                  <li class="list-inline-item"><a href="#menu"><span></span></a></li>
               </ul>
            </div>
         </div>
         <!-- /.mobile-menu -->
         <nav id="menu" class="stylehome1">
            <ul>
               <li class="list_one">
                  <a href="#"><span class="title">Home</span></a>
                  <!-- Level Two-->
               </li>
               <li class="list_two">
                  <a href="#"><span class="title">Programs</span></a>
                  <!-- Level Two-->
                  <ul>
                     <li><a href="mba.php">MBA</a></li>
                     <li><a href="mca.php">MCA</a></li>
                     <li><a href="bba.php">BBA</a></li>
                  </ul>
               </li>
               <li class="last">
                  <a href="contact.php"><span class="title">Contact</span></a>
               </li>
            </ul>
         </nav>
      </div>
      <!--Video Section-->
      <section id="maximage1" class="maximage-home home-four p0">
         <div class="container-fluid p0">
            <!-- Basic HTML -->
            <div id="maximage">
               <div class="first-item">
                  <img src="images/ahead-main.jpg"/>
               </div>
               <!-- <div class="second-item">
                  <img src="images/home/4.jpg" alt="4.jpg"/>
                  </div> -->
               <!-- <div class="fourth-item">
                  <img src="images/home/5.jpg" alt="5.jpg"/>
                  </div> -->
            </div>
            <div class="maxslider-content">
               <div class="lbox-caption">
                  <div class="lbox-details">
                     <div class="maxtext container">
                        <div class="col-lg-4 ml-auto aos-init aos-animate">
                           <form class="enquire_form" name="enquire_form" id="enquire_form" action="send_mail.php" method="POST" enctype="multipart/form-data">
                              <h3 class="h4 text-black form_ti">Let's Talk</h3>
                              <div class="form-group">
                                 <input type="text" class="form-control" placeholder="Name" name="student_name" required="" autocomplete="off">
                              </div>
                              <div class="form-group">
                                 <input type="tel" class="form-control" id="quantity" name="phnumber" pattern="\d{10}" placeholder="Mobile No" required="">
                              </div>
                              <div class="form-group">
                                 <input type="email" class="form-control" placeholder="Email" name="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" required="">
                              </div>
                              <div class="form-group">
                                 <select class="form-control" id="exampleFormControlSelect1" name="state" required="">
                                    <option value="" disabled="" selected="">State</option>
                                    <option value="Andhra Pradesh">Andhra Pradesh</option>
                                    <option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
                                    <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                                    <option value="Assam">Assam</option>
                                    <option value="Bihar">Bihar</option>
                                    <option value="Chandigarh">Chandigarh</option>
                                    <option value="Chhattisgarh">Chhattisgarh</option>
                                    <option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
                                    <option value="Daman and Diu">Daman and Diu</option>
                                    <option value="Delhi">Delhi</option>
                                    <option value="Lakshadweep">Lakshadweep</option>
                                    <option value="Puducherry">Puducherry</option>
                                    <option value="Goa">Goa</option>
                                    <option value="Gujarat">Gujarat</option>
                                    <option value="Haryana">Haryana</option>
                                    <option value="Himachal Pradesh">Himachal Pradesh</option>
                                    <option value="Jammu and Kashmir">Jammu and Kashmir</option>
                                    <option value="Jharkhand">Jharkhand</option>
                                    <option value="Karnataka">Karnataka</option>
                                    <option value="Kerala">Kerala</option>
                                    <option value="Madhya Pradesh">Madhya Pradesh</option>
                                    <option value="Maharashtra">Maharashtra</option>
                                    <option value="Manipur">Manipur</option>
                                    <option value="Meghalaya">Meghalaya</option>
                                    <option value="Mizoram">Mizoram</option>
                                    <option value="Nagaland">Nagaland</option>
                                    <option value="Odisha">Odisha</option>
                                    <option value="Punjab">Punjab</option>
                                    <option value="Rajasthan">Rajasthan</option>
                                    <option value="Sikkim">Sikkim</option>
                                    <option value="Tamil Nadu">Tamil Nadu</option>
                                    <option value="Telangana">Telangana</option>
                                    <option value="Tripura">Tripura</option>
                                    <option value="Uttar Pradesh">Uttar Pradesh</option>
                                    <option value="Uttarakhand">Uttarakhand</option>
                                    <option value="West Bengal">West Bengal</option>
                                 </select>
                              </div>
                              <div class="form-group">
                                 <input type="text" class="form-control" placeholder="City/Town" name="city" required="" autocomplete="off">
                              </div>
                              <div class="form-group">
                                 <select class="form-control" id="exampleFormControlSelect1" name="programme" required="">
                                    <option value="" disabled="" selected="">Programme</option>
                                    <option value="BBA">BBA</option>
                                    <option value="MBA">MBA</option>
                                    <option value="MCA (AI & DS)">MCA (AI & DS)</option>
                                 </select>
                              </div>
                              <div class="form-group">
                                 <input type="submit" class="btn btn-primary btn-pill submit_button" value="Submit">
                              </div>
                           </form>
                        </div>
                        <!-- <h1>MORE THAN 2500 ONLINE COURSES</h1>
                           <p>Own your future learning new skills online</p>
                           <div class="search_box_home4">
                           	<div class="ht_search_widget">
                           		<div class="header_search_widget">
                           			<form class="form-inline mailchimp_form">
                           				<input type="email" class="form-control mb-2 mr-sm-2" name="emailaddress" placeholder="Search for the software or skills you want to learn">
                           				<button type="submit" class="btn btn-primary mb-2"><span class="flaticon-magnifying-glass"></span></button>
                           			</form>
                           		</div>
                           	</div>
                           </div> -->
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!--Video Section Ends Here-->
      <div class="top_courses_iconbox">
         <div class="container">
            <div class="row row_home4">
               <div class="col-sm-6 col-lg-3">
                  <div class="home_icon_box home4">
                     <div class="icon"><img src="images/teacher.svg" style="width: 50px; height: 50px;"></div>
                     <p><span>1650+</span> <br> Ph.D. Faculty</p>
                  </div>
               </div>
               <div class="col-sm-6 col-lg-3">
                  <div class="home_icon_box home4">
                     <div class="icon"><img src="images/visitor.svg" style="width: 50px; height: 50px;"></div>
                     <p><span>200+</span> <br> Companies Visit</p>
                  </div>
               </div>
               <div class="col-sm-6 col-lg-3">
                  <div class="home_icon_box home4">
                     <div class="icon"><img src="images/graduated.svg" style="width: 50px; height: 50px;"></div>
                     <p><span>20250+</span> <br> Students</p>
                  </div>
               </div>
               <div class="col-sm-6 col-lg-3">
                  <div class="home_icon_box home4">
                     <div class="icon"><img src="images/money.svg" style="width: 50px; height: 50px;"></div>
                     <p><span>16.5</span> <br> Highest CTC / Salary
                     </p>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- Top Courses -->
      <section id="top-courses" class="top_cours">
         <div class="container">
            <div class="row">
               <div class="col-lg-6">
                  <div class="main-title text-left">
                     <h3 class="mt0">Explore the <span>Amrita<br> AHEAD</span> Programs</h3>
                     <!-- <p>Cum doctus civibus efficiantur in imperdiet deterruisset.</p> -->
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-lg-12">
                  <div id="options" class="alpha-pag full">
                     <div class="option-isotop">
                        <ul id="filter" class="option-set" data-option-key="filter">
                           <li class="list-inline-item"><a href="#all" data-option-value="*" class="selected">All Programs</a></li>
                           <li class="list-inline-item"><a href="#masters" data-option-value=".masters">Masters</a></li>
                           <li class="list-inline-item"><a href="#bachelors" data-option-value=".bachelors">Bachelors</a></li>
                           <li class="list-inline-item"><a href="#certificate" data-option-value=".certificate">Certificate</a></li>
                           <li class="list-inline-item"><a href="#diploma" data-option-value=".diploma">Diploma</a></li>
                        </ul>
                     </div>
                  </div>
                  <!-- FILTER BUTTONS -->
                  <div class="emply-text-sec">
                     <div class="row" id="masonry_abc">
                        <div class="col-md-6 col-lg-4 col-xl-4 all bachelors">
                           <div class="top_courses">
                              <div class="thumb">
                                 <img class="img-whp" src="images/programe.jpg" alt="t1.jpg">										
                              </div>
                              <div class="details">
                                 <div class="tc_content">
                                    <h5>BBA - Bachelor of Business Administration</h5>
                                    <p>4 Years | 4 Semesters</p>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-6 col-lg-4 col-xl-4 all masters">
                           <div class="top_courses">
                              <div class="thumb">
                                 <img class="img-whp" src="images/business_administration.jpg" alt="t1.jpg">										
                              </div>
                              <div class="details">
                                 <div class="tc_content">
                                    <h5>MBA - Master of Business Administration</h5>
                                    <p>3 Years | 6 Semesters</p>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-6 col-lg-4 col-xl-4 all masters">
                           <div class="top_courses">
                              <div class="thumb">
                                 <img class="img-whp" src="images/artificial_inteligence.jpg" alt="t1.jpg">										
                              </div>
                              <div class="details">
                                 <div class="tc_content">
                                    <h5>MCA - Artificial Intelligence and Data Science</h5>
                                    <p>2 Years | 6 Semesters</p>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!-- <div class="row">
               <div class="col-lg-12">
               	<div class="about_home3_shape_container">
               		<div class="about_home4_shape4"><img src="images/about/shape4.png" alt="shape4.png"></div>
               	</div>
               </div>
               </div> -->
         </div>
      </section>
      <!-- about4 home4 -->
      <section class="home4_about">
         <div class="container">
            <div class="row">
               <div class="col-lg-6 col-xl-6">
                  <div class="about_home3 main-title">
                     <h3>The <span>Amrita</span> advantage, <br> always <span>AHEAD</span></h3>
                     <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes.</p>
                     <a href="#" class="btn about_btn_home3">View More</a>
                     <!-- <ul class="partners_thumb_list">
                        <li class="list-inline-item"><a href="#"><img class="img-fluid" src="images/partners/1.png" alt="1.png"></a></li>
                        <li class="list-inline-item"><a href="#"><img class="img-fluid" src="images/partners/2.png" alt="2.png"></a></li>
                        <li class="list-inline-item"><a href="#"><img class="img-fluid" src="images/partners/3.png" alt="3.png"></a></li>
                        <li class="list-inline-item"><a href="#"><img class="img-fluid" src="images/partners/4.png" alt="4.png"></a></li>
                        </ul> -->
                     <section class="customer-logos slider">
                        <div class="slide"><img src="images/mslogo.jpg"></div>
                        <div class="slide"><img src="images/Bosch-logo.jpg"></div>
                        <div class="slide"><img src="images/amazon.jpg"></div>
                        <div class="slide"><img src="images/byjus.jpg"></div>
                        <!--  <div class="slide"><img src="https://image.freepik.com/free-vector/colors-curl-logo-template_23-2147536125.jpg"></div>
                           <div class="slide"><img src="https://image.freepik.com/free-vector/abstract-cross-logo_23-2147536124.jpg"></div>
                           <div class="slide"><img src="https://image.freepik.com/free-vector/football-logo-background_1195-244.jpg"></div>
                           <div class="slide"><img src="https://image.freepik.com/free-vector/background-of-spots-halftone_1035-3847.jpg"></div>
                           <div class="slide"><img src="https://image.freepik.com/free-vector/retro-label-on-rustic-background_82147503374.jpg"></div> -->
                     </section>
                  </div>
               </div>
               <div class="col-lg-6 col-xl-6">
                  <div class="row">
                     <div class="col-sm-6 col-lg-6">
                        <div class="home3_about_icon_box five">
                           <div class="icon"><img src="images/university.svg" style="width: 70px; height: 70px;"></div>
                           <div class="details campus_det">
                              <h4>4th Best University in India</h4>
                              <!-- <p>In the 2020 edition of the annual rankings released,</p> -->
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-6 col-lg-6">
                        <div class="home3_about_icon_box two">
                           <div class="icon"><img src="images/pencil.svg" style="width: 70px; height: 70px;"></div>
                           <div class="details campus_det">
                              <h4>16 Constituent Schools</h4>
                              <!-- <p>Sed cursus turpis vitae tortor donec eaque ipsa quaeab illo.</p> -->
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-6 col-lg-6">
                        <div class="home3_about_icon_box six">
                           <div class="icon"><img src="images/sharing.svg" style="width: 70px; height: 70px;"></div>
                           <div class="details campus_det">
                              <h4>Strong Alumni Network</h4>
                              <!-- <p>Sed cursus turpis vitae tortor donec eaque ipsa quaeab illo.</p> -->
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-6 col-lg-6">
                        <div class="home3_about_icon_box seven">
                           <div class="icon"><img src="images/earth-globe.svg" style="width: 70px; height: 70px;"></div>
                           <div class="details campus_det">
                              <h4>27 Collaborations with Top 100 World-Ranked Universities. </h4>
                              <!-- <p>Sed cursus turpis vitae tortor donec eaque ipsa quaeab illo.</p> -->
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!-- 			<div class="row">
               <div class="col-lg-12">
               	<div class="about_home3_shape_container">
               		<div class="about_home3_shape"><img src="images/about/shape1.png" alt="shape1.png"></div>
               	</div>
               </div>
               </div> -->
         </div>
      </section>
      <!-- School Category Courses -->
      <section id="our-courses" class="our-courses bgc-f9">
         <div class="container">
            <div class="row">
               <div class="col-lg-6">
                  <div class="main-title text-left">
                     <h3 class="mt0">The <span>Amrita</span> <br>Accreditations & Recognitions</h3>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-sm-6 col-lg-2 ranking">					
                  <img src="images/220px-NAAC_LOGO.png">
               </div>
               <div class="col-sm-6 col-lg-4 ranking">
                  <h4>National Assessment And Accreditation Council</h4>
                  <p>Amrita Vishwa Vidyapeetham was the youngest institution to be awarded with an 'A' grade by the National Assessment and Accreditation Council...</p>
                  <a target="blank" href="https://www.amrita.edu/about/awards-accreditations" class="btn btn-lg ranking_btn">Read More</a>		
               </div>
               <div class="col-sm-6 col-lg-2 ranking">					
                  <img src="images/images.png">
               </div>
               <div class="col-sm-6 col-lg-4 ranking">
                  <h4>National Accreditation Board for Hospitals & Healthcare Providers</h4>
                  <p>Amrita Institute of Medical Sciences has been granted NABH accreditation. Amrita is the first university teaching hospital to get NABH accreditation...</p>
                  <a target="blank" href="https://www.amrita.edu/about/awards-accreditations" class="btn btn-lg ranking_btn">Read More</a>				
               </div>
            </div>
            <div class="row customer-logos ranking-logos slider">
               <div class="slide"><img src="images/ranking-no1.svg"></div>
               <div class="slide"><img src="images/no1-international-faculty.svg"></div>
               <div class="slide"><img src="images/no-1-in-internationaloutlook.svg"></div>
               <div class="slide"><img src="images/4th-best-university.svg"></div>
               <div class="slide"><img src="images/ranking_01.svg"></div>
            </div>
         </div>
      </section>
      <div class="container" id="aside_bar">
         <div class="container position-relative" id="content">
            <div class="main-title text-left admission_process">
               <h3 class="mt0">Admissions <span>Process</span></h3>
            </div>
            <div class="row h-100">
               <aside class="col-md-4 bg-light" id="left">
                  <div class="mb-3 sticky-top" id="side">
                     <ul class="nav flex-md-column flex-row justify-content-between" id="sidenav">
                        <li class="nav-item"><a href="#sec1" class="nav-link active pl-0">Choose Programe</a></li>
                        <li class="nav-item"><a href="#sec2" class="nav-link pl-0">Talk to an Enrolment Specialist</a></li>
                        <li class="nav-item"><a href="#sec3" class="nav-link pl-0">Apply Online</a></li>
                     </ul>
                  </div>
               </aside>
               <main class="col py-5">
                  <div class="row position-relative">
                     <div class="col">
                        <div class="tab-content py-3 position-relative">
                           <div class="tab-pane active position-relative" id="tab1" role="tabpanel">
                              <div class="anchor" id="sec1"></div>
                              <h3 class="side_widg_ti">Programs Offered</h3>
                              <p>Sriracha biodiesel taxidermy organic post-ironic, Intelligentsia salvia mustache 90's code editing brunch. Butcher polaroid VHS art party, hashtag Brooklyn deep v PBR narwhal sustainable mixtape swag wolf squid tote bag.
                                 Tote bag cronut semiotics, raw denim deep v taxidermy messenger bag. Tofu YOLO Etsy, direct trade ethical Odd Future jean shorts paleo. Forage Shoreditch tousled aesthetic irony, street art organic Bushwick artisan
                                 cliche semiotics ugh synth chillwave meditation. Shabby chic lomo plaid vinyl chambray Vice. Vice sustainable cardigan, Williamsburg master cleanse hella DIY 90's blog.
                              </p>
                              <p>Ethical Kickstarter PBR asymmetrical lo-fi. Dreamcatcher street art Carles, stumptown gluten-free Kickstarter artisan Wes Anderson wolf pug. Godard sustainable you probably haven't heard of them, vegan farm-to-table Williamsburg
                                 slow-carb readymade disrupt deep v. Meggings seitan Wes Anderson semiotics, cliche American Apparel whatever. Helvetica cray plaid, vegan brunch Banksy leggings +1 direct trade. Wayfarers codeply PBR selfies. Banh mi
                                 McSweeney's Shoreditch selfies, forage fingerstache food truck occupy YOLO Pitchfork fixie iPhone fanny pack art party Portland.
                              </p>
                              <p>Sriracha biodiesel taxidermy organic post-ironic, Intelligentsia salvia mustache 90's code editing brunch. Butcher polaroid VHS art party, hashtag Brooklyn deep v PBR narwhal sustainable mixtape swag wolf squid tote bag.
                                 Tote bag cronut semiotics, raw denim deep v taxidermy messenger bag. Tofu YOLO Etsy, direct trade ethical Odd Future jean shorts paleo. Forage Shoreditch tousled aesthetic irony, street art organic Bushwick artisan
                                 cliche semiotics ugh synth chillwave meditation. Shabby chic lomo plaid vinyl chambray Vice. Vice sustainable cardigan, Williamsburg master cleanse hella DIY 90's blog.
                              </p>
                              <hr>
                              <div class="anchor" id="sec2"></div>
                              <h3 class="side_widg_ti">Talk to an Enrolment Specialist</h3>
                              <p>Intelligentsia salvia mustache 90's code editing brunch. Butcher polaroid VHS art party, hashtag Brooklyn deep v PBR narwhal sustainable mixtape swag wolf squid tote bag. Tote bag cronut semiotics, raw denim deep v taxidermy
                                 messenger bag. Tofu YOLO Etsy, direct trade ethical Odd Future jean shorts paleo. Forage Shoreditch tousled aesthetic irony, street art organic Bushwick artisan cliche semiotics ugh synth chillwave meditation. Shabby
                                 chic lomo plaid vinyl chambray Vice. Vice sustainable cardigan, Williamsburg master cleanse hella DIY 90's blog.
                              </p>
                              <p>Dreamcatcher street art Carles, stumptown gluten-free Kickstarter artisan Wes Anderson wolf pug. Godard sustainable you probably haven't heard of them, vegan farm-to-table Williamsburg slow-carb readymade disrupt deep v.
                                 Meggings seitan Wes Anderson semiotics, cliche American Apparel whatever. Helvetica cray plaid, vegan brunch Banksy leggings +1 direct trade. Wayfarers codeply PBR selfies. Banh mi McSweeney's Shoreditch selfies, forage
                                 fingerstache food truck occupy YOLO Pitchfork fixie iPhone fanny pack art party Portland.
                              </p>
                              <hr>
                              <div class="anchor" id="sec3"></div>
                              <h3 class="side_widg_ti">Apply Online</h3>
                              <p>Ethical Kickstarter PBR asymmetrical lo-fi. Dreamcatcher street art Carles, stumptown gluten-free Kickstarter artisan Wes Anderson wolf pug. Godard sustainable you probably haven't heard of them, vegan farm-to-table Williamsburg
                                 slow-carb readymade disrupt deep v. Meggings seitan Wes Anderson semiotics, cliche American Apparel whatever. Helvetica cray plaid, vegan brunch Banksy leggings +1 direct trade. Wayfarers codeply PBR selfies. Banh mi
                                 McSweeney's Shoreditch selfies, forage fingerstache food truck occupy YOLO Pitchfork fixie iPhone fanny pack art party Portland.
                              </p>
                           </div>
                        </div>
                     </div>
               </main>
               </div>
            </div>
         </div>
         <!-- Our Testimonials -->
         <!-- 	<section id="our-testimonials" class="our-testimonial">
            <div class="container-fluid">
            	<div class="row">
            		<div class="col-lg-6 offset-lg-3">
            			<div class="main-title text-center">
            				<h3 class="mt0">What People Say</h3>
            				<p>Cum doctus civibus efficiantur in imperdiet deterruisset.</p>
            			</div>
            		</div>
            	</div>
            	<div class="row">
            		<div class="col-lg-12">
            			<div class="testimonial_slider_home2">
            				<div class="item">
            					<div class="testimonial_item home2">
            						<div class="details">
            							<div class="icon"><span class="fa fa-quote-left"></span></div>
            							<p>It was really fun getting to know the team during the project. They were all helpful in answering my questions and made me feel completely at ease.The design ended up being twice as good as I could have ever envisioned!</p>
            						</div>
            						<div class="thumb">
            							<img class="img-fluid rounded-circle" src="images/testimonial/1.jpg" alt="1.jpg">
            							<div class="title">Arun s</div>
            							<div class="subtitle">Student</div>
            						</div>
            					</div>
            				</div>
            				<div class="item">
            					<div class="testimonial_item home2">
            						<div class="details">
            							<div class="icon"><span class="fa fa-quote-left"></span></div>
            							<p>It was really fun getting to know the team during the project. They were all helpful in answering my questions and made me feel completely at ease.The design ended up being twice as good as I could have ever envisioned!</p>
            						</div>
            						<div class="thumb">
            							<img class="img-fluid rounded-circle" src="images/testimonial/2.jpg" alt="2.jpg">
            							<div class="title">John C</div>
            							<div class="subtitle">Student</div>
            						</div>
            					</div>
            				</div>
            				<div class="item">
            					<div class="testimonial_item home2">
            						<div class="details">
            							<div class="icon"><span class="fa fa-quote-left"></span></div>
            							<p>It was really fun getting to know the team during the project. They were all helpful in answering my questions and made me feel completely at ease.The design ended up being twice as good as I could have ever envisioned!</p>
            						</div>
            						<div class="thumb">
            							<img class="img-fluid rounded-circle" src="images/testimonial/3.jpg" alt="3.jpg">
            							<div class="title">Amal</div>
            							<div class="subtitle">Student</div>
            						</div>
            					</div>
            				</div>
            			</div>
            		</div>
            	</div>
            </div>
            </section> -->
         <!-- Our Footer -->
         <section class="footer_one home4">
            <div class="container">
               <div class="row">
                  <div class="col-sm-6 col-md-4 col-md-3 col-lg-3 abouy_footer">
                     <div class="footer_contact_widget home4">
                        <!-- <h4>About</h4> -->
                        <img class="img-fluid foot_logo" src="images/aheadlogosticky.svg" alt="header-logo3.png" style="width: 270px;">
                     </div>
                     <div class="footer_social_widget mt15">
                        <ul class="text-center">
                           <li class="list-inline-item footer_social_item"><a href="#"><img src="images/facebook.svg" style="width: 25px;"></a></li>
                           <li class="list-inline-item footer_social_item"><a href="#"><img src="images/whatsapp.svg" style="width: 25px;"></a></li>
                           <li class="list-inline-item footer_social_item"><a href="#"><img src="images/twitter.svg" style="width: 25px;"></a></li>
                           <li class="list-inline-item footer_social_item"><a href="#"><img src="images/instagram.svg" style="width: 25px;"></a></li>
                           <li class="list-inline-item footer_social_item"><a href="#"><img src="images/youtube.svg" style="width: 25px;"></a></li>
                        </ul>
                     </div>
                  </div>
                  <div class="col-sm-6 col-md-4 col-md-3 col-lg-2">
                     <div class="footer_company_widget home4">
                        <h4>Programs</h4>
                        <ul class="list-unstyled">
                           <li><a href="#">Undergraduate</a></li>
                           <li><a href="#">Postgraduate</a></li>
                           <li><a href="page-contact.html">Diploma</a></li>
                           <li><a href="#">Certificate Courses</a></li>
                        </ul>
                     </div>
                  </div>
                  <div class="col-sm-6 col-md-4 col-md-3 col-lg-2">
                     <div class="footer_program_widget home4">
                        <h4>Resources</h4>
                        <ul class="list-unstyled">
                           <li><a href="#">FAQs</a></li>
                           <li><a href="#">Student Support</a></li>
                           <li><a href="#">Testimonials</a></li>
                           <li><a href="#">Policies</a></li>
                           <li><a href="#">Honor Code</a></li>
                           <li><a href="#">Corporate</a></li>
                        </ul>
                     </div>
                  </div>
                  <div class="col-sm-6 col-md-4 col-md-3 col-lg-2">
                     <div class="footer_program_widget home4">
                        <h4>About Amrita</h4>
                        <ul class="list-unstyled">
                           <li><a href="#">Rankings</a></li>
                           <li><a href="#">Accreditation</a></li>
                           <li><a href="#">Chancellor</a></li>
                           <li><a href="#">Newsletters</a></li>
                           <li><a href="#">Press Media</a></li>
                        </ul>
                     </div>
                  </div>
                  <div class="col-sm-6 col-md-4 col-md-3 col-lg-2">
                     <div class="footer_company_widget home4">
                        <h4>Locations</h4>
                        <ul class="list-unstyled">
                           <li><a href="#">Amritapuri</a></li>
                           <li><a href="#">Chennai</a></li>
                           <li><a href="page-contact.html">Coimbatore</a></li>
                           <li><a href="#">Kochi</a></li>
                           <li><a href="#">Mysuru</a></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!-- Our Footer Bottom Area -->
         <section class="footer_bottom_area home4 pt30 pb30">
            <div class="container">
               <div class="row">
                  <div class="col-lg-6 offset-lg-12 text-left">
                     <div class="copyright-widget text-center">
                        <p>© Amrita Vishwa Vidyapeetham 2020. All Rights Reserved.</p>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <div class="elfsight-app-73c8b59b-e812-4c8a-bbf7-a4aad381cb44"></div>
         <a class="scrollToHome home4" href="#"><i class="flaticon-up-arrow-1"></i></a>
      </div>
      <!-- Wrapper End -->
      <script type="text/javascript" src="js/jquery-3.3.1.js"></script>
      <script type="text/javascript" src="js/jquery-migrate-3.0.0.min.js"></script>
      <script type="text/javascript" src="js/popper.min.js"></script>
      <script type="text/javascript" src="js/bootstrap.min.js"></script>
      <script type="text/javascript" src="js/jquery.mmenu.all.js"></script>
      <script type="text/javascript" src="js/ace-responsive-menu.js"></script>
      <script type="text/javascript" src="js/bootstrap-select.min.js"></script>
      <script type="text/javascript" src="js/isotop.js"></script>
      <script type="text/javascript" src="js/snackbar.min.js"></script>
      <script type="text/javascript" src="js/simplebar.js"></script>
      <script type="text/javascript" src="js/parallax.js"></script>
      <script type="text/javascript" src="js/scrollto.js"></script>
      <script type="text/javascript" src="js/jquery-scrolltofixed-min.js"></script>
      <script type="text/javascript" src="js/jquery.counterup.js"></script>
      <script type="text/javascript" src="js/wow.min.js"></script>
      <script type="text/javascript" src="js/progressbar.js"></script>
      <script type="text/javascript" src="js/slider.js"></script>
      <script type="text/javascript" src="js/timepicker.js"></script>
      <!-- Custom script for all pages --> 
      <script type="text/javascript" src="js/script.js"></script>
      <!-- <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script> -->
      <script>
         $(function() {
                         //const scriptURL = 'https://script.google.com/macros/s/AKfycbxJZY6TLVls3xcDuxjX8_dXwlxxoCgximDvEko7XSDGubexRSZg/exec';
                         const scriptURL = "https://script.google.com/macros/s/AKfycbwJFeRVXj1aw8NapOmraeCytVEryXa8NnnmhUKsnoMaQrMcng-C/exec";
                         const form = document.forms['enquire_form']
                       
                         $('#enquire_form').submit(function(e){
                           e.preventDefault();
                           $(this).find('input[type=submit]').attr("disabled", true);
                           fetch(scriptURL, { method: 'POST', body: new FormData(form)})
                             .then(response => console.log('Success!', response))
                             .catch(error => console.error('Error!', error.message))
                             setTimeout(() => { // hide after three seconds
                                 document.getElementById('enquire_form').submit();
                               }, 500);
                         });
                     });
      </script>
      <!------ LOGO SLIDER ---------->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.js"></script>
      <script type="text/javascript">
         $(document).ready(function(){
            $('.customer-logos').slick({
                slidesToShow: 3,
                slidesToScroll: 1,
                autoplay: true,
                autoplaySpeed: 1500,
                arrows: false,
                dots: false,
                pauseOnHover: false,
                responsive: [{
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 4
                    }
                }, {
                    breakpoint: 520,
                    settings: {
                        slidesToShow: 2
                    }
                }]
            });
         });
      </script>
   </body>
</html>