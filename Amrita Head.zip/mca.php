<!DOCTYPE html>
<html dir="ltr" lang="en">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="keywords" content="">
      <meta name="description" content="">
      <!-- css file -->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <link rel="stylesheet" href="css/menu.css">
      <link rel="stylesheet" href="css/style.css">
      <link rel="stylesheet" href="css/custom.css">
      <!-- Responsive stylesheet -->
      <link rel="stylesheet" href="css/responsive.css">
      <!-- Title -->
      <title>MCA | AHEAD - Online Degree Programs</title>
      <!-- Favicon -->
      <link href="images/amrita-ahead-logo.png" sizes="194x194" rel="shortcut icon" type="image/x-icon" />
      <link href="images/amrita-ahead-logo.png" sizes="194x194" rel="shortcut icon" />
   </head>
   <body>
      <div class="wrapper">
         <div class="header_top home4">
            <div class="container">
               <div class="row">
                  <div class="col-lg-5 col-xl-5">
                     <ul class="home4_header_top_contact">
                        <li class="list-inline-item"><a target="blank" href="https://www.amrita.edu/international">INTERNATIONAL</a></li>
                        <li class="list-inline-item"><a target="blank" href="https://www.amrita.edu/amritians">ALUMNI</a></li>
                        <li class="list-inline-item"><a target="blank" href="https://www.amrita.edu/faculty">FACULTY</a></li>
                     </ul>
                  </div>
                  <div class="col-lg-7 col-xl-7">
                     <ul class="sign_up_btn home4 dn-smd text-right">
                        <li class="list-inline-item"><a target="blank" href="https://www.amrita.edu/admissions" class="btn btn-md"><span class="dn-md">ADMISSION - 2021</span></a></li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
         <!-- Main Header Nav -->
         <header class="header-nav menu_style_home_four navbar-scrolltofixed stricky main-menu">
            <div class="container">
               <!-- Ace Responsive Menu -->
               <nav>
                  <!-- Menu Toggle btn-->
                  <div class="menu-toggle">
                     <img class="nav_logo_img img-fluid" src="images/amrita-ahead-logo.jpg" alt="header-logo.jpg">
                     <button type="button" id="menu-btn">
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     </button>
                  </div>
                  <a href="index.php" class="navbar_brand float-left dn-smd">
                  <img class="logo1 img-fluid" src="images/aheadlogo.svg" alt="header-logo" style="width: 300px; height: 65px;">
                  <img class="logo2 img-fluid" src="images/aheadlogosticky.svg" alt="header-logo2.png" style="height: 50px;">		            
                  </a>
                  <!-- Responsive Menu Structure-->
                  <ul id="respMenu" class="ace-responsive-menu" data-menu-style="horizontal">
                     <li class="last">
                        <a href="contact.php"><span class="title">Contact</span></a>
                     </li>
                     <li class="list_two">
                        <a href="#"><span class="title">Programs</span></a>
                        <!-- Level Two-->
                        <ul>
                           <li><a href="mba.php">MBA</a></li>
                           <li><a href="mca.php">MCA</a></li>
                           <li><a href="bba.php">BBA</a></li>
                        </ul>
                     </li>
                     <li class="list_one">
                        <a href="index.php"><span class="title">Home</span></a>
                        <!-- Level Two-->
                     </li>
                  </ul>
               </nav>
               <!-- End of Responsive Menu -->
            </div>
         </header>
         <!-- Main Header Nav For Mobile -->
         <div id="page" class="stylehome1 h0">
            <div class="mobile-menu">
               <div class="header stylehome1">
                  <div class="main_logo_home2">
                     <img class="nav_logo_img img-fluid float-left mt20" src="images/aheadlogo.svg" alt="header-logo.png" style="width: 236px;">
                  </div>
                  <ul class="menu_bar_home2">
                     <li class="list-inline-item">
                     </li>
                     <li class="list-inline-item"><a href="#menu"><span></span></a></li>
                  </ul>
               </div>
            </div>
            <!-- /.mobile-menu -->
            <nav id="menu" class="stylehome1">
               <ul>
                  <li class="list_one">
                     <a href="#"><span class="title">Home</span></a>
                     <!-- Level Two-->
                  </li>
                  <li class="list_two">
                     <a href="#"><span class="title">Programs</span></a>
                     <!-- Level Two-->
                     <ul>
                        <li><a href="mba.php">MBA</a></li>
                        <li><a href="mca.php">MCA</a></li>
                        <li><a href="bba.php">BBA</a></li>
                     </ul>
                  </li>
                  <li class="last">
                     <a href="contact.php"><span class="title">Contact</span></a>
                  </li>
               </ul>
            </nav>
         </div>
         <!--Video Section-->
         <section id="maximage1" class="maximage-home home-four p0">
            <div class="container-fluid p0 contact_bg">
               <!-- Basic HTML -->
               <div id="maximage">
                  <div class="first-item">
                     <img src="images/head_bg.jpg"/>
                  </div>
                  <!-- <div class="second-item">
                     <img src="images/home/4.jpg" alt="4.jpg"/>
                     </div> -->
                  <!-- <div class="fourth-item">
                     <img src="images/home/5.jpg" alt="5.jpg"/>
                     </div> -->
               </div>
               <div class="maxslider-content">
                  <div class="lbox-caption">
                     <div class="lbox-details">
                        <div class="maxtext container pr_container">
                           <!-- 							<div class="col-lg-4 ml-auto aos-init aos-animate">			
                              </div> -->
                           <h1 class="prg_ti">MCA Artificial Intelligence <br>and Data Science</h1>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!-- Inner Page Breadcrumb -->
         <!-- 	<section class="inner_page_breadcrumb csv2">
            <div class="container">
            	<div class="row">
            		<div class="col-xl-9">
            			<div class="breadcrumb_content">
            				<div class="cs_row_one csv2">
            					<div class="cs_ins_container">
            						<h3 class="cs_title color-white">MCA Artificial Intelligence <br>and Data Science</h3>
            					</div>
            				</div>
            			</div>
            		</div>
            	</div>
            </div>
            </section> -->
         <!-- Our Team Members -->
         <section class="course-single2 pb40">
            <div class="container">
               <div class="row">
                  <div class="col-md-12 col-lg-8 col-xl-9">
                     <div class="row">
                        <div class="col-lg-12">
                           <div class="courses_single_container">
                              <div class="cs_row_one">
                                 <div class="cs_ins_container">
                                    <div class="courses_big_thumb">
                                       <div class="thumb">
                                          <iframe class="iframe_video" src="https://www.youtube.com/embed/UcGfAI5gjtQ" frameborder="0" allowfullscreen></iframe>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="cs_rwo_tabs csv2">
                                 <ul class="nav nav-tabs" id="myTab" role="tablist">
                                    <li class="nav-item">
                                       <a class="nav-link active" id="Overview-tab" data-toggle="tab" href="#Overview" role="tab" aria-controls="Overview" aria-selected="true">Overview</a>
                                    </li>
                                    <li class="nav-item">
                                       <a class="nav-link" id="course-tab" data-toggle="tab" href="#course" role="tab" aria-controls="course" aria-selected="false">Course Curriculum</a>
                                    </li>
                                    <li class="nav-item">
                                       <a class="nav-link" id="review-tab" data-toggle="tab" href="#review" role="tab" aria-controls="review" aria-selected="false">Admissions</a>
                                    </li>
                                    <li class="nav-item">
                                       <a class="nav-link" id="instructor-tab" data-toggle="tab" href="#instructor" role="tab" aria-controls="instructor" aria-selected="false">FAQs</a>
                                    </li>
                                    <li class="nav-item">
                                       <a class="nav-link" id="faculty-tab" data-toggle="tab" href="#faculty" role="tab" aria-controls="faculty" aria-selected="false">World Class Faculty</a>
                                    </li>
                                 </ul>
                                 <div class="tab-content" id="myTabContent">
                                    <div class="tab-pane fade show active" id="Overview" role="tabpanel" aria-labelledby="Overview-tab">
                                       <div class="cs_row_two csv2">
                                          <div class="cs_overview">
                                             <h4 class="title">Amrita AHEAD MCA-AI& DS Advantage</h4>
                                             <ul class="cs_course_syslebus">
                                                <li>
                                                   <i class="fa fa-check"></i>
                                                   <p>UGC approved</p>
                                                </li>
                                                <li>
                                                   <i class="fa fa-check"></i>
                                                   <p>Affordable</p>
                                                </li>
                                                <li>
                                                   <i class="fa fa-check"></i>
                                                   <p>Outstanding faculty from India and abroad</p>
                                                </li>
                                                <li>
                                                   <i class="fa fa-check"></i>
                                                   <p>Complete your MCA-AI & DS at your own pace (2 to 4 years)</p>
                                                </li>
                                                <li>
                                                   <i class="fa fa-check"></i>
                                                   <p>Industry-aligned curriculum</p>
                                                </li>
                                                <li>
                                                   <i class="fa fa-check"></i>
                                                   <p>Advanced tools and applications covered</p>
                                                </li>
                                                <li>
                                                   <i class="fa fa-check"></i>
                                                   <p>Opportunity to work in research centers on industry projects</p>
                                                </li>
                                                <li>
                                                   <i class="fa fa-check"></i>
                                                   <p>Course Mentors</p>
                                                </li>
                                             </ul>
                                             <h4 class="title">Eligibility</h4>
                                             <p class="mb20">Undergraduate degree: Bachelor of Computer Applications (BCA) or Bachelor’s Degree in Computer Science / Engineering or Bachelor's Degree in Science / Commerce / Arts with Mathematics at 10+2 level with minimum 50% percentage marks. Students in their final year can apply with the last completed semester results.<br>
                                                Students with Foreign Education: Bachelor’s Degree - any of the above-mentioned degrees. Certificate of Equivalence from Association of Indian Universities is needed. This is required by any student with a Foreign Education who wishes to apply to an Indian University. Please refer to <a href="https://aiu.ac.in/">https://aiu.ac.in/</a>
                                             </p>
                                             <p><strong>Candidates with work experience will have an added advantage for admissions.</strong></p>
                                             <h4 class="title">Course duration</h4>
                                             <div class="shortcode_widget_table">
                                                <div class="ui_kit_table">
                                                   <table class="table">
                                                      <thead class="thead-light">
                                                         <tr>
                                                            <th scope="col">Limits</th>
                                                            <th scope="col">No. of years</th>
                                                         </tr>
                                                      </thead>
                                                      <tbody>
                                                         <tr>
                                                            <td>Minimum</td>
                                                            <td>2</td>
                                                         </tr>
                                                         <tr>
                                                            <td>Maximum</td>
                                                            <td>4</td>
                                                         </tr>
                                                      </tbody>
                                                   </table>
                                                </div>
                                             </div>
                                             <h4 class="title">Fee Structure</h4>
                                             <p>will be updated shortly.</p>
                                             <!-- <div class="shortcode_widget_table">
                                                <div class="ui_kit_table">
                                                		<table class="table">
                                                			<thead class="thead-light">
                                                		    	<tr>
                                                		    		<th scope="col">Per Year  (In Rs)</th>
                                                		    		<th scope="col">Total Fee (In Rs)</th>			    		
                                                		    	</tr>
                                                			</thead>
                                                			<tbody>
                                                		    	<tr>
                                                		    		<td>60,000</td>
                                                		    		<td>1,20,000</td>
                                                		    	</tr>
                                                			</tbody>
                                                		</table>
                                                	</div>
                                                </div> -->
                                          </div>
                                       </div>
                                    </div>
                                    <div class="tab-pane fade" id="course" role="tabpanel" aria-labelledby="review-tab">
                                       <div class="cs_row_three csv2">
                                          <div class="course_content">
                                             <div class="details">
                                                <div id="accordion" class="panel-group cc_tab">
                                                   <div class="panel">
                                                      <div class="panel-heading">
                                                         <h4 class="panel-title">
                                                            <a href="#panelBodyCourseStart" class="accordion-toggle link" data-toggle="collapse" data-parent="#accordion">Semester 1</a>
                                                         </h4>
                                                      </div>
                                                      <div id="panelBodyCourseStart" class="panel-collapse collapse show">
                                                         <div class="panel-body">
                                                            <table class="table table-bordered">
                                                               <thead>
                                                                  <tr>
                                                                     <th scope="col">Title of Course</th>
                                                                     <th scope="col">Total Credits of Course</th>
                                                                  </tr>
                                                               </thead>
                                                               <tbody>
                                                                  <tr>
                                                                     <td>Foundations of Machine Learning(Soft core 1)</td>
                                                                     <td>3</td>
                                                                  </tr>
                                                                  <tr>
                                                                     <td>Mathematics for Data Science I</td>
                                                                     <td>3</td>
                                                                  </tr>
                                                                  <tr>
                                                                     <td>Foundations of Computer systems</td>
                                                                     <td>3</td>
                                                                  </tr>
                                                                  <tr>
                                                                     <td>Natural Language Processing</td>
                                                                     <td>3</td>
                                                                  </tr>
                                                                  <tr>
                                                                     <td>Design and Analysis of Algorithms</td>
                                                                     <td>3</td>
                                                                  </tr>
                                                                  <tr>
                                                                     <td>Business Analytics</td>
                                                                     <td>3</td>
                                                                  </tr>
                                                               </tbody>
                                                            </table>
                                                         </div>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                             <div class="details">
                                                <div id="accordion" class="panel-group cc_tab">
                                                   <div class="panel">
                                                      <div class="panel-heading">
                                                         <h4 class="panel-title">
                                                            <a href="#panelBodyCourseBrief" class="accordion-toggle link" data-toggle="collapse" data-parent="#accordion">Semester 2</a>
                                                         </h4>
                                                      </div>
                                                      <div id="panelBodyCourseBrief" class="panel-collapse collapse">
                                                         <div class="panel-body">
                                                            <table class="table table-bordered">
                                                               <thead>
                                                                  <tr>
                                                                     <th scope="col">Title of Course</th>
                                                                     <th scope="col">Total Credits of Course</th>
                                                                  </tr>
                                                               </thead>
                                                               <tbody>
                                                                  <tr>
                                                                     <td>Deep Learning for AI</td>
                                                                     <td>3</td>
                                                                  </tr>
                                                                  <tr>
                                                                     <td>Mathematics for Data Science -II</td>
                                                                     <td>3</td>
                                                                  </tr>
                                                                  <tr>
                                                                     <td>Data Engineering for AI</td>
                                                                     <td>3</td>
                                                                  </tr>
                                                                  <tr>
                                                                     <td>Elective -I</td>
                                                                     <td>3</td>
                                                                  </tr>
                                                                  <tr>
                                                                     <td>Elective -II</td>
                                                                     <td>3</td>
                                                                  </tr>
                                                                  <tr>
                                                                     <td>Elective -III</td>
                                                                     <td>3</td>
                                                                  </tr>
                                                               </tbody>
                                                            </table>
                                                         </div>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                             <div class="details">
                                                <div id="accordion" class="panel-group cc_tab">
                                                   <div class="panel">
                                                      <div class="panel-heading">
                                                         <h4 class="panel-title">
                                                            <a href="#panelBodyCourseLow" class="accordion-toggle link" data-toggle="collapse" data-parent="#accordion">Semester 3</a>
                                                         </h4>
                                                      </div>
                                                      <div id="panelBodyCourseLow" class="panel-collapse collapse">
                                                         <div class="panel-body">
                                                            <table class="table table-bordered">
                                                               <thead>
                                                                  <tr>
                                                                     <th scope="col">Title of Course</th>
                                                                     <th scope="col">Total Credits of Course</th>
                                                                  </tr>
                                                               </thead>
                                                               <tbody>
                                                                  <tr>
                                                                     <td>Complex Network Analysis</td>
                                                                     <td>3</td>
                                                                  </tr>
                                                                  <tr>
                                                                     <td>Computer Vision</td>
                                                                     <td>3</td>
                                                                  </tr>
                                                                  <tr>
                                                                     <td>Elective-IV</td>
                                                                     <td>3</td>
                                                                  </tr>
                                                                  <tr>
                                                                     <td>Elective-V</td>
                                                                     <td>3</td>
                                                                  </tr>
                                                                  <tr>
                                                                     <td>Elective-VI</td>
                                                                     <td>3</td>
                                                                  </tr>
                                                               </tbody>
                                                            </table>
                                                         </div>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                             <div class="details">
                                                <div id="accordion" class="panel-group cc_tab">
                                                   <div class="panel">
                                                      <div class="panel-heading">
                                                         <h4 class="panel-title">
                                                            <a href="#panelBodyCourseType" class="accordion-toggle link" data-toggle="collapse" data-parent="#accordion">Semester 4</a>
                                                         </h4>
                                                      </div>
                                                      <div id="panelBodyCourseType" class="panel-collapse collapse">
                                                         <div class="panel-body">
                                                            <table class="table table-bordered">
                                                               <thead>
                                                                  <tr>
                                                                     <th scope="col">Title of Course</th>
                                                                     <th scope="col">Total Credits of Course</th>
                                                                  </tr>
                                                               </thead>
                                                               <tbody>
                                                                  <tr>
                                                                     <td>Industry Project part II</td>
                                                                     <td>18</td>
                                                                  </tr>
                                                               </tbody>
                                                            </table>
                                                         </div>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="tab-pane fade" id="instructor" role="tabpanel" aria-labelledby="review-tab">
                                       <div class="cs_row_four csv2">
                                          <div class="about_ins_container">
                                             <h4 class="title_faq">Academics</h4>
                                             <h5 class="faq_ti">1) What is the MCA-AI & DS Program?</h5>
                                             <p>This 2-year postgraduate online programme of MCA with specialization in AI & Data Science is designed to groom professionals technically sound in advanced learning systems & methodologies that are based on algorithms of Artificial Intelligence. This programme follows an industry mentored curriculum which equips the professionals with advanced application-level knowledge in cutting edge technologies. The structure of course is designed as hands-on based which helps students to apply their knowledge which helps them align with industry standards from the very beginning of the course.</p>
                                             <h5 class="faq_ti">2) Is the program certified by UGC?</h5>
                                             <p>Yes, It is certified by UGC. It is equivalent to any other degree offered by UGC.</p>
                                             <h5 class="faq_ti">3) How long can I take to complete my program?</h5>
                                             <p>The Online MCA-AI & DS programme is a 2-year programme. You, as a learner can either complete it within the stipulated time frame of 2 years or you can complete it within a maximum allowed duration of 4 years.</p>
                                             <h5 class="faq_ti">4) How will you conduct the online program?</h5>
                                             <p>Every week, there will be a 1-hour live session. Reading materials and video lectures will be uploaded each week prior to live sessions.
                                                A 2-hour discussion forum is planned every week for each course. This will help the students to clarify their doubts and solve the questions/assignments in a timely manner.
                                                Approximately 12 weeks of e-content is prepared inclusive of lab materials. Each week at least 1 quiz will be conducted and 1 assignment(lab/theory) will be given.
                                             </p>
                                             <h5 class="faq_ti">5) Do you offer live sessions to clear doubts?</h5>
                                             <p>Yes, there will be a 1-hour live interactive session and a 2-hour discussion group forum every week to answer your questions and clear doubts.
                                             </p>
                                             <h5 class="faq_ti">6) How are the exams conducted?</h5>
                                             <p>Examinations are conducted as per the new regulations through the Online Technology Enabled Proctored mode. The exam pattern comprises internal and external assessments. The weightage is as follows: Internal(assignments) 30% and External(end-term examination) 70%. Section A- Subjective, Section B- Case Studies And Section C- MCQs.</p>
                                             <h5 class="faq_ti">7) Why should one study Artificial Intelligence and Data Sciences?</h5>
                                             <ul>
                                                <li>One of the most demanding careers in all sectors which show no sign of saturation in the next 20 years</li>
                                                <li>The credible report says in 2021, artificial intelligence (AI) augmentation will create $2.9 trillion of business value and 6.2 billion hours of worker productivity globally.</li>
                                                <li>World Economic Forum in its report “The Future of Jobs: 2018” clearly states that the boom of AI and its tremendous application in diverse areas could open about 58 million new job opportunities’ by 2022</li>
                                                <li> Statistics show over 375 million existing workers need to be skilled in AI to retain their position.</li>
                                             </ul>
                                             <h5 class="faq_ti">8) What are the job prospects?</h5>
                                             <p>Upon successful completion of the programme, prospective and esteemed job profiles that graduates gain are: Data Scientist, Business Analyst, Data Engineer, Applied Machine Learning engineer, Analytics Leader/data Science Manager, Qualitative expert/Social Scientist</p>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="tab-pane fade" id="review" role="tabpanel" aria-labelledby="review-tab">
                                       <div class="cs_row_four csv2">
                                          <div class="about_ins_container">
                                             <h5 class="faq_ti">1) What is the Eligibility Criteria?</h5>
                                             <p>Undergraduate degree: Bachelor of Computer Applications (BCA) or Bachelor’s Degree in Computer Science / Engineering or Bachelor's Degree in Science / Commerce / Arts with Mathematics at 10+2 level with minimum 50% percentage marks. Students in their final year can apply with the last completed semester results. 
                                                Students with Foreign Education: Bachelor’s Degree - any of the above-mentioned degrees. Certificate of Equivalence from Association of Indian Universities (required by any student with foreign education who wishes to apply to an Indian University, refer to <a href="https://aiu.ac.in/">https://aiu.ac.in/</a>
                                             </p>
                                             <p><strong>Candidates with work experience will have an added advantage during admissions.</strong></p>
                                             <h5 class="faq_ti">2) What is the fees structure?</h5>
                                             <p>The fee is Rs. 60,000 per year. The total fee is Rs. 1,20,000 for the full MCA program.</p>
                                             <h5 class="faq_ti">3) Is there an admission fee?</h5>
                                             <p>No, there is no admission fee when you apply. It is free.</p>
                                             <h5 class="faq_ti">4) How do I apply?</h5>
                                             <p>It is a simple and easy process. You need to fill out our application form in order to apply.</p>
                                             <h5 class="faq_ti">5) How do I contact you?</h5>
                                             <p>You can contact us via Email, Call or WhatsApp. You can also chat with us through the chat window present on our website.</p>
                                             <p><strong>Email: ahead@amrita.edu </strong></p>
                                             <p><strong>Mobile: 8590240617</strong></p>
                                             <p><strong>Whatsapp:8590007473</strong></p>
                                             <p><strong>We are always here to help you and make your journey as easy as possible.</strong></p>
                                             <h5 class="faq_ti">6) I am an International Student, can I also apply? </h5>
                                             <p>Yes, International Students are welcome.  Students with foreign education can also apply. Certificate of Equivalence from Association of Indian Universities is needed. This is required by any student with a foreign education who wishes to apply to an Indian University. Please refer to <a href="https://aiu.ac.in/">https://aiu.ac.in/</a></p>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-4 col-xl-3">
                     <form class="enquire_form instructor_pricing_widget csv2" name="enquire_form" id="enquire_form" action="send_mail.php" method="POST" enctype="multipart/form-data">
                        <h3 class="h4 text-black form_ti">Let's Talk</h3>
                        <div class="form-group">
                           <input type="text" class="form-control" placeholder="Name" name="student_name" required="" autocomplete="off">
                        </div>
                        <div class="form-group">
                           <input type="tel" class="form-control" id="quantity" name="phnumber" pattern="\d{10}" placeholder="Mobile No" required="">
                        </div>
                        <div class="form-group">
                           <input type="email" class="form-control" placeholder="Email" name="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" required="">
                        </div>
                        <div class="form-group">
                           <select class="form-control" id="exampleFormControlSelect1" name="programme" required="">
                              <option value="" disabled="" selected="">Programme</option>
                              <option value="BBA">BBA</option>
                              <option value="MBA">MBA</option>
                              <option value="MCA (AI &amp; DS)">MCA (AI &amp; DS)</option>
                           </select>
                        </div>
                        <div class="form-group">
                           <input type="submit" class="btn btn-primary btn-pill submit_button" value="Submit">
                        </div>
                     </form>
                     <div class="feature_course_widget csv1">
                        <ul class="list-group">
                           <h4 class="title">Course Features</h4>
                           <li class="d-flex justify-content-between align-items-center">
                              Lectures <span class="float-right">6</span>
                           </li>
                           <li class="d-flex justify-content-between align-items-center">
                              Quizzes <span class="float-right">1</span>
                           </li>
                           <li class="d-flex justify-content-between align-items-center">
                              Duration <span class="float-right">3 hours</span>
                           </li>
                           <li class="d-flex justify-content-between align-items-center">
                              Skill level <span class="float-right">All level</span>
                           </li>
                           <li class="d-flex justify-content-between align-items-center">
                              Language <span class="float-right">English</span>
                           </li>
                           <li class="d-flex justify-content-between align-items-center">
                              Assessments <span class="float-right">Yes</span>
                           </li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!-- Testimonials -->
         <!-- <section class="our-testimonials bgc-fa">
            <div class="container">
            	<div class="row">
            		<div class="col-lg-6 offset-lg-3">
            			<div class="main-title text-center">
            				<h3 class="mt0 testimonial_tyi">Students Testimonials</h3>
            				<p>Cum doctus civibus efficiantur in imperdiet deterruisset.</p>
            			</div>
            		</div>
            	</div>
            	<div class="row">
            		<div class="col-lg-10 offset-lg-1">
            			<div class="testimonial_slider_home3">
            				<div class="item">
            					<div class="testimonial_grid">
            						<div class="t_icon home3"><span class="flaticon-quotation-mark"></span></div>
            						<div class="testimonial_content">
            							<div class="thumb">
            								<img class="img-fluid" src="images/testimonial/1.jpg" alt="1.jpg">
            								<h4>Alex Gibson</h4>
            								<p>Telemarketer</p>
            							</div>
            							<div class="details">
            								<p>This is the best job-board theme that our company has come across! Without JobHunt i’d be homeless, they found me a job and got me sorted out quickly with everything! Can’t quite…</p>
            							</div>
            						</div>
            					</div>
            				</div>
            				<div class="item">
            					<div class="testimonial_grid">
            						<div class="t_icon home3"><span class="flaticon-quotation-mark"></span></div>
            						<div class="testimonial_content">
            							<div class="thumb">
            								<img class="img-fluid" src="images/testimonial/2.jpg" alt="2.jpg">
            								<h4>Alex Gibson</h4>
            								<p>Telemarketer</p>
            							</div>
            							<div class="details">
            								<p>This is the best job-board theme that our company has come across! Without JobHunt i’d be homeless, they found me a job and got me sorted out quickly with everything! Can’t quite…</p>
            							</div>
            						</div>
            					</div>
            				</div>
            				<div class="item">
            					<div class="testimonial_grid">
            						<div class="t_icon home3"><span class="flaticon-quotation-mark"></span></div>
            						<div class="testimonial_content">
            							<div class="thumb">
            								<img class="img-fluid" src="images/testimonial/3.jpg" alt="3.jpg">
            								<h4>Alex Gibson</h4>
            								<p>Telemarketer</p>
            							</div>
            							<div class="details">
            								<p>This is the best job-board theme that our company has come across! Without JobHunt i’d be homeless, they found me a job and got me sorted out quickly with everything! Can’t quite…</p>
            							</div>
            						</div>
            					</div>
            				</div>
            				<div class="item">
            					<div class="testimonial_grid">
            						<div class="t_icon home3"><span class="flaticon-quotation-mark"></span></div>
            						<div class="testimonial_content">
            							<div class="thumb">
            								<img class="img-fluid" src="images/testimonial/4.jpg" alt="4.jpg">
            								<h4>Alex Gibson</h4>
            								<p>Telemarketer</p>
            							</div>
            							<div class="details">
            								<p>This is the best job-board theme that our company has come across! Without JobHunt i’d be homeless, they found me a job and got me sorted out quickly with everything! Can’t quite…</p>
            							</div>
            						</div>
            					</div>
            				</div>
            				<div class="item">
            					<div class="testimonial_grid">
            						<div class="t_icon home3"><span class="flaticon-quotation-mark"></span></div>
            						<div class="testimonial_content">
            							<div class="thumb">
            								<img class="img-fluid" src="images/testimonial/5.jpg" alt="5.jpg">
            								<h4>Alex Gibson</h4>
            								<p>Telemarketer</p>
            							</div>
            							<div class="details">
            								<p>This is the best job-board theme that our company has come across! Without JobHunt i’d be homeless, they found me a job and got me sorted out quickly with everything! Can’t quite…</p>
            							</div>
            						</div>
            					</div>
            				</div>
            			</div>
            		</div>
            	</div>
            </div>
            </section>
            -->
         <!-- about4 home4 -->
         <section class="home4_about">
            <div class="container">
               <div class="row">
                  <div class="col-lg-12 text-center">
                     <div class="about_home3 main-title">
                        <h3 class="mt0 testimonial_tyi">Placements</h3>
                        <section class="customer-logos slider">
                           <div class="slide"><img src="images/mslogo.jpg"></div>
                           <div class="slide"><img src="images/Bosch-logo.jpg"></div>
                           <div class="slide"><img src="images/amazon.jpg"></div>
                           <div class="slide"><img src="images/byjus.jpg"></div>
                           <div class="slide"><img src="images/mslogo.jpg"></div>
                           <div class="slide"><img src="images/Bosch-logo.jpg"></div>
                        </section>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!-- about4 home4 -->
         <!-- Our Footer -->
         <section class="footer_one home4">
            <div class="container">
               <div class="row">
                  <div class="col-sm-6 col-md-4 col-md-3 col-lg-3 abouy_footer">
                     <div class="footer_contact_widget home4">
                        <!-- <h4>About</h4> -->
                        <img class="img-fluid foot_logo" src="images/aheadlogosticky.svg" alt="header-logo3.png" style="width: 270px;">
                     </div>
                     <div class="footer_social_widget mt15">
                        <ul class="text-center">
                           <li class="list-inline-item footer_social_item"><a href="#"><img src="images/facebook.svg" style="width: 25px;"></a></li>
                           <li class="list-inline-item footer_social_item"><a href="#"><img src="images/whatsapp.svg" style="width: 25px;"></a></li>
                           <li class="list-inline-item footer_social_item"><a href="#"><img src="images/twitter.svg" style="width: 25px;"></a></li>
                           <li class="list-inline-item footer_social_item"><a href="#"><img src="images/instagram.svg" style="width: 25px;"></a></li>
                           <li class="list-inline-item footer_social_item"><a href="#"><img src="images/youtube.svg" style="width: 25px;"></a></li>
                        </ul>
                     </div>
                  </div>
                  <div class="col-sm-6 col-md-4 col-md-3 col-lg-2">
                     <div class="footer_company_widget home4">
                        <h4>Programs</h4>
                        <ul class="list-unstyled">
                           <li><a href="#">Undergraduate</a></li>
                           <li><a href="#">Postgraduate</a></li>
                           <li><a href="page-contact.html">Diploma</a></li>
                           <li><a href="#">Certificate Courses</a></li>
                        </ul>
                     </div>
                  </div>
                  <div class="col-sm-6 col-md-4 col-md-3 col-lg-2">
                     <div class="footer_program_widget home4">
                        <h4>Resources</h4>
                        <ul class="list-unstyled">
                           <li><a href="#">FAQs</a></li>
                           <li><a href="#">Student Support</a></li>
                           <li><a href="#">Testimonials</a></li>
                           <li><a href="#">Policies</a></li>
                           <li><a href="#">Honor Code</a></li>
                           <li><a href="#">Corporate</a></li>
                        </ul>
                     </div>
                  </div>
                  <div class="col-sm-6 col-md-4 col-md-3 col-lg-2">
                     <div class="footer_program_widget home4">
                        <h4>About Amrita</h4>
                        <ul class="list-unstyled">
                           <li><a href="#">Rankings</a></li>
                           <li><a href="#">Accreditation</a></li>
                           <li><a href="#">Chancellor</a></li>
                           <li><a href="#">Newsletters</a></li>
                           <li><a href="#">Press Media</a></li>
                        </ul>
                     </div>
                  </div>
                  <div class="col-sm-6 col-md-4 col-md-3 col-lg-2">
                     <div class="footer_company_widget home4">
                        <h4>Locations</h4>
                        <ul class="list-unstyled">
                           <li><a href="#">Amritapuri</a></li>
                           <li><a href="#">Chennai</a></li>
                           <li><a href="page-contact.html">Coimbatore</a></li>
                           <li><a href="#">Kochi</a></li>
                           <li><a href="#">Mysuru</a></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!-- Our Footer Bottom Area -->
         <section class="footer_bottom_area home4 pt30 pb30">
            <div class="container">
               <div class="row">
                  <div class="col-lg-6 offset-lg-12 text-left">
                     <div class="copyright-widget text-center">
                        <p>© Amrita Vishwa Vidyapeetham 2020. All Rights Reserved.</p>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <a class="scrollToHome" href="#"><i class="flaticon-up-arrow-1"></i></a>
      </div>
      <!-- Wrapper End -->
      <script type="text/javascript" src="js/jquery-3.3.1.js"></script>
      <script type="text/javascript" src="js/jquery-migrate-3.0.0.min.js"></script>
      <script type="text/javascript" src="js/popper.min.js"></script>
      <script type="text/javascript" src="js/bootstrap.min.js"></script>
      <script type="text/javascript" src="js/jquery.mmenu.all.js"></script>
      <script type="text/javascript" src="js/ace-responsive-menu.js"></script>
      <script type="text/javascript" src="js/bootstrap-select.min.js"></script>
      <script type="text/javascript" src="js/snackbar.min.js"></script>
      <script type="text/javascript" src="js/simplebar.js"></script>
      <script type="text/javascript" src="js/parallax.js"></script>
      <script type="text/javascript" src="js/scrollto.js"></script>
      <script type="text/javascript" src="js/jquery-scrolltofixed-min.js"></script>
      <script type="text/javascript" src="js/jquery.counterup.js"></script>
      <script type="text/javascript" src="js/wow.min.js"></script>
      <script type="text/javascript" src="js/progressbar.js"></script>
      <script type="text/javascript" src="js/slider.js"></script>
      <script type="text/javascript" src="js/timepicker.js"></script>
      <!-- Custom script for all pages --> 
      <script type="text/javascript" src="js/script.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.js"></script>
      <script>
         $(function() {
                         //const scriptURL = 'https://script.google.com/macros/s/AKfycbxJZY6TLVls3xcDuxjX8_dXwlxxoCgximDvEko7XSDGubexRSZg/exec';
                         const scriptURL = "https://script.google.com/macros/s/AKfycbwJFeRVXj1aw8NapOmraeCytVEryXa8NnnmhUKsnoMaQrMcng-C/exec";
                         const form = document.forms['enquire_form']
                       
                         $('#enquire_form').submit(function(e){
                           e.preventDefault();
                           $(this).find('input[type=submit]').attr("disabled", true);
                           fetch(scriptURL, { method: 'POST', body: new FormData(form)})
                             .then(response => console.log('Success!', response))
                             .catch(error => console.error('Error!', error.message))
                             setTimeout(() => { // hide after three seconds
                                 document.getElementById('enquire_form').submit();
                               }, 500);
                         });
                     });
      </script>
      <!------ LOGO SLIDER ---------->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.js"></script>
      <script type="text/javascript">
         $(document).ready(function(){
            $('.customer-logos').slick({
                slidesToShow: 5,
                slidesToScroll: 1,
                autoplay: true,
                autoplaySpeed: 1500,
                arrows: false,
                dots: false,
                pauseOnHover: false,
                responsive: [{
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 5
                    }
                }, {
                    breakpoint: 520,
                    settings: {
                        slidesToShow: 2
                    }
                }]
            });
         });
      </script>
   </body>
</html>