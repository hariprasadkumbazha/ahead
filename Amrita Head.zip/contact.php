<!DOCTYPE html>
<html dir="ltr" lang="en">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="keywords" content="">
      <meta name="description" content="">
      <!-- css file -->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <link rel="stylesheet" href="css/menu.css">
      <link rel="stylesheet" href="css/style.css">
      <link rel="stylesheet" href="css/custom.css">
      <!-- Responsive stylesheet -->
      <link rel="stylesheet" href="css/responsive.css">
      <!-- Title -->
      <title>Contact | AHEAD - Online Degree Programs</title>
      <!-- Favicon -->
      <link href="images/amrita-ahead-logo.png" sizes="194x194" rel="shortcut icon" type="image/x-icon" />
      <link href="images/amrita-ahead-logo.png" sizes="194x194" rel="shortcut icon" />
   </head>
   <body>
      <div class="wrapper">
         <div class="header_top home4">
            <div class="container">
               <div class="row">
                  <div class="col-lg-5 col-xl-5">
                     <ul class="home4_header_top_contact">
                        <li class="list-inline-item"><a target="blank" href="https://www.amrita.edu/international">INTERNATIONAL</a></li>
                        <li class="list-inline-item"><a target="blank" href="https://www.amrita.edu/amritians">ALUMNI</a></li>
                        <li class="list-inline-item"><a target="blank" href="https://www.amrita.edu/faculty">FACULTY</a></li>
                     </ul>
                  </div>
                  <div class="col-lg-7 col-xl-7">
                     <ul class="sign_up_btn home4 dn-smd text-right">
                        <li class="list-inline-item"><a target="blank" href="https://www.amrita.edu/admissions" class="btn btn-md"><span class="dn-md">ADMISSION - 2021</span></a></li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
         <!-- Main Header Nav -->
         <header class="header-nav menu_style_home_four navbar-scrolltofixed stricky main-menu">
            <div class="container">
               <!-- Ace Responsive Menu -->
               <nav>
                  <!-- Menu Toggle btn-->
                  <div class="menu-toggle">
                     <img class="nav_logo_img img-fluid" src="images/amrita-ahead-logo.jpg" alt="header-logo.jpg">
                     <button type="button" id="menu-btn">
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     </button>
                  </div>
                  <a href="index.php" class="navbar_brand float-left dn-smd">
                  <img class="logo1 img-fluid" src="images/aheadlogo.svg" alt="header-logo" style="width: 300px; height: 65px;">
                  <img class="logo2 img-fluid" src="images/aheadlogosticky.svg" alt="header-logo2.png" style="height: 50px;">		            
                  </a>
                  <!-- Responsive Menu Structure-->
                  <ul id="respMenu" class="ace-responsive-menu" data-menu-style="horizontal">
                     <li class="last">
                        <a href="#"><span class="title">Contact</span></a>
                     </li>
                     <li class="list_two">
                        <a href="#"><span class="title">Programs</span></a>
                        <!-- Level Two-->
                        <ul>
                           <li><a href="mba.php">MBA</a></li>
                           <li><a href="mca.php">MCA</a></li>
                           <li><a href="bba.php">BBA</a></li>
                        </ul>
                     </li>
                     <li class="list_one">
                        <a href="index.php"><span class="title">Home</span></a>
                        <!-- Level Two-->
                     </li>
                  </ul>
               </nav>
               <!-- End of Responsive Menu -->
            </div>
         </header>
         <!-- Main Header Nav For Mobile -->
         <div id="page" class="stylehome1 h0">
            <div class="mobile-menu">
               <div class="header stylehome1">
                  <div class="main_logo_home2">
                     <img class="nav_logo_img img-fluid float-left mt20" src="images/aheadlogo.svg" alt="header-logo.png" style="width: 236px;">
                  </div>
                  <ul class="menu_bar_home2">
                     <li class="list-inline-item">
                     </li>
                     <li class="list-inline-item"><a href="#menu"><span></span></a></li>
                  </ul>
               </div>
            </div>
            <!-- /.mobile-menu -->
            <nav id="menu" class="stylehome1">
               <ul>
                  <li class="list_one">
                     <a href="#"><span class="title">Home</span></a>
                     <!-- Level Two-->
                  </li>
                  <li class="list_two">
                     <a href="#"><span class="title">Programs</span></a>
                     <!-- Level Two-->
                     <ul>
                        <li><a href="mba.php">MBA</a></li>
                        <li><a href="mca.php">MCA</a></li>
                        <li><a href="bba.php">BBA</a></li>
                     </ul>
                  </li>
                  <li class="last">
                     <a href="#"><span class="title">Contact</span></a>
                  </li>
               </ul>
            </nav>
         </div>
         <!--Video Section-->
         <section id="maximage1" class="maximage-home home-four p0">
            <div class="container-fluid p0 contact_bg">
               <!-- Basic HTML -->
               <div id="maximage">
                  <div class="first-item">
                     <img src="images/head_bg.jpg"/>
                  </div>
                  <!-- <div class="second-item">
                     <img src="images/home/4.jpg" alt="4.jpg"/>
                     </div> -->
                  <!-- <div class="fourth-item">
                     <img src="images/home/5.jpg" alt="5.jpg"/>
                     </div> -->
               </div>
               <div class="maxslider-content">
                  <div class="lbox-caption">
                     <div class="lbox-details">
                        <div class="maxtext container contact_container">
                           <!-- 							<div class="col-lg-4 ml-auto aos-init aos-animate">			
                              </div> -->
                           <h1 class="breadcrumb_title">Contact Us</h1>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!-- How It's Work -->
         <section class="our-contact">
            <div class="container-fluid">
               <div class="row">
                  <!-- 				<div class="col-sm-6 col-lg-4">
                     <div class="contact_localtion text-center">
                     	<div class="icon"><span class="flaticon-placeholder-1"></span></div>
                     	<h4>Our Location</h4>
                     	<p>Amrita Vishwa Vidyapeetham
                     	Amritapuri Campus
                     	Amritapuri, Clappana P. O.
                     	Kollam - 690525
                     	Kerala, India</p>
                     </div>
                     </div> -->
                  <div class="col-sm-6 col-lg-6">
                     <div class="contact_localtion text-center">
                        <div class="icon"><span class="flaticon-phone-call"></span></div>
                        <h4>Contact No</h4>
                        <p class="mb0">Mobile: 8590240617<br> WhatsaApp: 8590007473</p>
                     </div>
                  </div>
                  <div class="col-sm-6 col-lg-6">
                     <div class="contact_localtion text-center">
                        <div class="icon"><span class="flaticon-email"></span></div>
                        <h4>Write Some Words</h4>
                        <p>ahead@amrita.edu</p>
                     </div>
                  </div>
               </div>
               <div class="row">
                  <div class="col-lg-6 map_div">
                     <div><iframe src="https://www.google.com/maps/d/embed?mid=1dMkyN42CMYvIKMqSCoVUm886b9A" width="640" height="600"></iframe></div>
                  </div>
                  <div class="col-lg-6 form_grid contact_blk_grid">
                     <h4 class="mb5">Send a Message</h4>
                     <form class="contact_form" id="contact_form" name="contact_form" action="#" method="post" novalidate="novalidate">
                        <div class="row">
                           <div class="col-sm-12">
                              <div class="form-group">			                    	
                                 <input id="form_name" name="form_name" class="form-control" required="" type="text" placeholder="Name">
                              </div>
                           </div>
                           <div class="col-sm-12">
                              <div class="form-group">
                                 <input id="form_email" name="form_email" class="form-control required email" required="" type="email" placeholder="Email">
                              </div>
                           </div>
                           <div class="col-sm-12">
                              <div class="form-group">
                                 <input id="form_subject" name="form_subject" class="form-control required" required="" type="text" placeholder="Subject">
                              </div>
                           </div>
                           <div class="col-sm-12">
                              <div class="form-group">
                                 <textarea id="form_message" name="form_message" class="form-control required" rows="5" required="" placeholder="Message"></textarea>
                              </div>
                              <div class="form-group ui_kit_button mb0">
                                 <button type="submit" class="btn contact_button">Submit</button>
                              </div>
                           </div>
                        </div>
                     </form>
                  </div>
               </div>
            </div>
         </section>
         <!-- Our Footer -->
         <section class="footer_one home4">
            <div class="container">
               <div class="row">
                  <div class="col-sm-6 col-md-4 col-md-3 col-lg-3 abouy_footer">
                     <div class="footer_contact_widget home4">
                        <!-- <h4>About</h4> -->
                        <img class="img-fluid foot_logo" src="images/aheadlogosticky.svg" alt="header-logo3.png" style="width: 270px;">
                     </div>
                     <div class="footer_social_widget mt15">
                        <ul class="text-center">
                           <li class="list-inline-item footer_social_item"><a href="#"><img src="images/facebook.svg" style="width: 25px;"></a></li>
                           <li class="list-inline-item footer_social_item"><a href="#"><img src="images/whatsapp.svg" style="width: 25px;"></a></li>
                           <li class="list-inline-item footer_social_item"><a href="#"><img src="images/twitter.svg" style="width: 25px;"></a></li>
                           <li class="list-inline-item footer_social_item"><a href="#"><img src="images/instagram.svg" style="width: 25px;"></a></li>
                           <li class="list-inline-item footer_social_item"><a href="#"><img src="images/youtube.svg" style="width: 25px;"></a></li>
                        </ul>
                     </div>
                  </div>
                  <div class="col-sm-6 col-md-4 col-md-3 col-lg-2">
                     <div class="footer_company_widget home4">
                        <h4>Programs</h4>
                        <ul class="list-unstyled">
                           <li><a href="#">Undergraduate</a></li>
                           <li><a href="#">Postgraduate</a></li>
                           <li><a href="page-contact.html">Diploma</a></li>
                           <li><a href="#">Certificate Courses</a></li>
                        </ul>
                     </div>
                  </div>
                  <div class="col-sm-6 col-md-4 col-md-3 col-lg-2">
                     <div class="footer_program_widget home4">
                        <h4>Resources</h4>
                        <ul class="list-unstyled">
                           <li><a href="#">FAQs</a></li>
                           <li><a href="#">Student Support</a></li>
                           <li><a href="#">Testimonials</a></li>
                           <li><a href="#">Policies</a></li>
                           <li><a href="#">Honor Code</a></li>
                           <li><a href="#">Corporate</a></li>
                        </ul>
                     </div>
                  </div>
                  <div class="col-sm-6 col-md-4 col-md-3 col-lg-2">
                     <div class="footer_program_widget home4">
                        <h4>About Amrita</h4>
                        <ul class="list-unstyled">
                           <li><a href="#">Rankings</a></li>
                           <li><a href="#">Accreditation</a></li>
                           <li><a href="#">Chancellor</a></li>
                           <li><a href="#">Newsletters</a></li>
                           <li><a href="#">Press Media</a></li>
                        </ul>
                     </div>
                  </div>
                  <div class="col-sm-6 col-md-4 col-md-3 col-lg-2">
                     <div class="footer_company_widget home4">
                        <h4>Locations</h4>
                        <ul class="list-unstyled">
                           <li><a href="#">Amritapuri</a></li>
                           <li><a href="#">Chennai</a></li>
                           <li><a href="page-contact.html">Coimbatore</a></li>
                           <li><a href="#">Kochi</a></li>
                           <li><a href="#">Mysuru</a></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!-- Our Footer Bottom Area -->
         <section class="footer_bottom_area home4 pt30 pb30">
            <div class="container">
               <div class="row">
                  <div class="col-lg-6 offset-lg-12 text-left">
                     <div class="copyright-widget text-center">
                        <p>© Amrita Vishwa Vidyapeetham 2020. All Rights Reserved.</p>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <a class="scrollToHome home4" href="#"><i class="flaticon-up-arrow-1"></i></a>
      </div>
      <!-- Wrapper End -->
      <script type="text/javascript" src="js/jquery-3.3.1.js"></script>
      <script type="text/javascript" src="js/jquery-migrate-3.0.0.min.js"></script>
      <script type="text/javascript" src="js/popper.min.js"></script>
      <script type="text/javascript" src="js/bootstrap.min.js"></script>
      <script type="text/javascript" src="js/jquery.mmenu.all.js"></script>
      <script type="text/javascript" src="js/ace-responsive-menu.js"></script>
      <script type="text/javascript" src="js/bootstrap-select.min.js"></script>
      <script type="text/javascript" src="js/snackbar.min.js"></script>
      <script type="text/javascript" src="js/simplebar.js"></script>
      <script type="text/javascript" src="js/parallax.js"></script>
      <script type="text/javascript" src="js/scrollto.js"></script>
      <script type="text/javascript" src="js/jquery-scrolltofixed-min.js"></script>
      <script type="text/javascript" src="js/jquery.counterup.js"></script>
      <script type="text/javascript" src="js/wow.min.js"></script>
      <script type="text/javascript" src="js/progressbar.js"></script>
      <script type="text/javascript" src="js/slider.js"></script>
      <script type="text/javascript" src="js/timepicker.js"></script>
      <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAAz77U5XQuEME6TpftaMdX0bBelQxXRlM&callback=initMap"type="text/javascript"></script>
      <script type="text/javascript" src="js/googlemaps1.js"></script>
      <!-- Custom script for all pages --> 
      <script type="text/javascript" src="js/script.js"></script>
   </body>
</html>